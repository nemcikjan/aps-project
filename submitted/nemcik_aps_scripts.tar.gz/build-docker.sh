#!/bin/bash

docker build -f Dockerfile -t jany15/aps:latest .